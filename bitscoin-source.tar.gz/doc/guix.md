# Bootstrappable Bitscoin Core Builds

See [contrib/guix/README.md](../contrib/guix/README.md)
